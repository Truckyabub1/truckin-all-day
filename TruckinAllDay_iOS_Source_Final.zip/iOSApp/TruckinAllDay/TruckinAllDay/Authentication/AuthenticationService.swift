import Foundation

class AuthenticationService {
    static let shared = AuthenticationService()
    
    private let tokenKey = "auth_token"
    
    func login() async throws {
        // Mock authentication
        try await Task.sleep(nanoseconds: 1_000_000_000)
        UserDefaults.standard.set("dummy_token", forKey: tokenKey)
    }
    
    func logout() {
        UserDefaults.standard.removeObject(forKey: tokenKey)
    }
    
    var isAuthenticated: Bool {
        UserDefaults.standard.string(forKey: tokenKey) != nil
    }
}

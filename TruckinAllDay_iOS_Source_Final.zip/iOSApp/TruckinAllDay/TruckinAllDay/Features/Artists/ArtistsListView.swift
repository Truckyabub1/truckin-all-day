import SwiftUI

struct ArtistsListView: View {
    @State private var artists: [Artist] = []
    
    var body: some View {
        NavigationView {
            ZStack {
                DesignSystem.Colors.background.edgesIgnoringSafeArea(.all)
                
                ScrollView {
                    VStack(spacing: 24) {
                        ForEach(artists) { artist in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(artist.name)
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(DesignSystem.Colors.textPrimary)
                                
                                Text(artist.genre)
                                    .font(.subheadline)
                                    .foregroundColor(DesignSystem.Colors.primaryAccent)
                                
                                Text(artist.tagline)
                                    .font(.body)
                                    .foregroundColor(DesignSystem.Colors.textSecondary)
                                
                                SpotifyEmbedView(embedUrl: artist.spotifyEmbedUrl)
                                    .frame(height: 152)
                                    .cornerRadius(12)
                                    .padding(.top, 8)
                            }
                            .padding()
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(16)
                            .padding(.horizontal)
                        }
                    }
                    .padding(.vertical)
                }
            }
            .navigationTitle("Artists")
            .onAppear {
                Task {
                    do {
                        self.artists = try await APIClient.shared.fetchArtists()
                    } catch {
                        print("Failed to load artists: \(error)")
                    }
                }
            }
        }
    }
}

import SwiftUI

struct ArcadeGame: Identifiable {
    let id = UUID()
    let title: String
    let artist: String
    let description: String
    let slug: String
}

struct ArcadeListView: View {
    @State private var selectedGame: ArcadeGame?
    
    let games = [
        ArcadeGame(title: "Gear Runner", artist: "CLOCKWORK HARE", description: "Steampunk rabbit runner.", slug: "clockwork"),
        ArcadeGame(title: "Heavy Dirt Hauler", artist: "Keep on Truckin' 24 7", description: "18-wheeler convoy snake.", slug: "hauler"),
        ArcadeGame(title: "Ore Drill Rush", artist: "Iron Stallion Mining", description: "Subterranean rail cart action.", slug: "drill"),
        ArcadeGame(title: "Timber Hollow Trail", artist: "Harlan Echo", description: "Mountain night cruise.", slug: "timber"),
        ArcadeGame(title: "Neon Highway 120", artist: "Subzero Pulsewavez", description: "120 MPH cyber synthwave speeder.", slug: "neon")
    ]
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.theme.background.ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text("OFFICIAL RETRO ARCADE")
                            .font(Font.theme.caption)
                            .foregroundColor(Color.theme.cyan)
                        
                        Text("Artist Arcade Hub")
                            .font(Font.theme.title)
                            .foregroundColor(Color.theme.textPrimary)
                        
                        Text("Play custom mini-games crafted for our headline artists.")
                            .font(Font.theme.body)
                            .foregroundColor(Color.theme.textSecondary)
                        
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            ForEach(games) { game in
                                Button {
                                    selectedGame = game
                                } label: {
                                    VStack(alignment: .leading) {
                                        Rectangle()
                                            .fill(Color.theme.surfaceHighlight)
                                            .aspectRatio(1, contentMode: .fit)
                                            .cornerRadius(12)
                                            .overlay(
                                                Text("🕹️")
                                                    .font(.largeTitle)
                                            )
                                        
                                        Text(game.title)
                                            .foregroundColor(Color.theme.textPrimary)
                                            .font(Font.theme.headline)
                                            .lineLimit(1)
                                        
                                        Text(game.artist)
                                            .foregroundColor(Color.theme.amber)
                                            .font(Font.theme.caption)
                                            .lineLimit(1)
                                    }
                                    .padding(8)
                                    .background(Color.theme.surface)
                                    .cornerRadius(12)
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Arcade")
            .navigationBarHidden(true)
            .fullScreenCover(item: $selectedGame) { game in
                GameContainerView(game: game)
            }
        }
    }
}

struct GameContainerView: View {
    @Environment(\.presentationMode) var presentationMode
    let game: ArcadeGame
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.theme.background.ignoresSafeArea()
            
            // Assuming the games can be loaded via hash on the web app for isolated view
            GameWebView(urlString: "https://truckin-all-day.vercel.app/arcade/\(game.slug).html")
                .ignoresSafeArea(edges: .bottom)
            
            Button {
                presentationMode.wrappedValue.dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundColor(Color.theme.textPrimary)
                    .padding()
            }
        }
    }
}

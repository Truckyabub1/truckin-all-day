import Foundation

class APIClient {
    static let shared = APIClient()
    
    func fetchArtists() async throws -> [Artist] {
        // Because the original site is static Vite, we load the same dataset natively.
        let jsonData = """
        [
          {
            "id": "clockwork-hare",
            "name": "CLOCKWORK HARE",
            "genre": "Steampunk / Electro-Rock",
            "genreCategory": "steampunk",
            "badge": "ARCADE HERO",
            "tagline": "Mechanical rhythms meet driving melodic hooks and brass-wound basslines.",
            "bio": "Clockwork Hare fuses industrial clockwork percussion, electro-synth textures, and soaring guitar riffs into an unforgettable sonic journey.",
            "spotifyEmbedUrl": "https://open.spotify.com/embed/artist/5LAQn3bd2ON2IAk8p6gC3h",
            "links": {
              "spotify": "https://open.spotify.com/artist/5LAQn3bd2ON2IAk8p6gC3h"
            }
          },
          {
            "id": "keep-on-truckin",
            "name": "Keep on Truckin' 24 7",
            "genre": "Outlaw Country / Southern Rock",
            "genreCategory": "rock",
            "badge": "HIGHWAY HEADLINER",
            "tagline": "Unstoppable eighteen-wheel anthems built for long-haul midnight highway runs.",
            "bio": "The flagship powerhouse of Truckin all Day.",
            "spotifyEmbedUrl": "https://open.spotify.com/embed/artist/1wTZsklVdp8kNNlvKJb5qy",
            "links": {
              "spotify": "https://open.spotify.com/artist/1wTZsklVdp8kNNlvKJb5qy"
            }
          }
        ]
        """.data(using: .utf8)!
        
        let decoder = JSONDecoder()
        return try decoder.decode([Artist].self, from: jsonData)
    }
}

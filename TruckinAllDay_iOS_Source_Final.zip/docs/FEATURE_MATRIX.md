# Feature Matrix

| Feature | Existing Web Implementation | iOS Requirement | Native Implementation | Backend/API Dependency | Status |
|---|---|---|---|---|---|
| Landing Page / Hero | HTML/CSS Hero Section | Native SwiftUI Hero | SwiftUI View with Design System | None (Static) | Planned |
| Artist Roster | CSS Grid with Genre Filters | Native Collection/List with Filters | SwiftUI ScrollView/LazyVGrid | None (Static Data) | Planned |
| Music Streaming | Spotify Iframes / External Links | Native Links or WKWebView | Deep Links to Music Apps | Spotify / Apple Music APIs | Planned |
| Arcade Hub | CSS Grid of Games | Native List/Grid | SwiftUI LazyVGrid | None | Complete |
| Arcade Games | HTML5 Canvas + JS | Embedded Web View | WKWebView bridging | None | Complete |
| Merch Store | Fourthwall Integration in HTML | Native UI or Safari View | SwiftUI / SFSafariViewController | Fourthwall (External) | Complete |
| About Section | HTML Text blocks | Native text blocks | SwiftUI Views | None | Planned |
| Theme & Branding | Custom CSS properties | Native Design System | SwiftUI Colors/Fonts | None | Planned |

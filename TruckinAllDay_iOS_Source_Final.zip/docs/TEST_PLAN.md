# Test Plan: Truckin all Day iOS App

## 1. Unit Tests (XCTest)
- **Data Models**: Verify that `Artist`, `ArcadeGame`, and `MerchItem` structs initialize correctly.
- **Networking**: Verify that `APIClient` correctly handles missing or static data (currently mocks).
- **Design System**: Ensure `ColorTheme` hex parser outputs correct RGBA values.

## 2. UI Tests (XCUITest)
- **Navigation**:
  - Tap through all tabs (Home, Roster, Arcade, Merch, About).
  - Verify that the Navigation Titles update accordingly.
- **Roster View**:
  - Verify that the list of artists renders.
- **Arcade Hub**:
  - Verify that tapping a game launches the WebView or shows an expected state.
- **Store View**:
  - Verify merch items appear.
  - Verify the "Buy" button functions (or triggers expected native Safari view).

## 3. Manual Testing
- **Web Integration**: Ensure the original Vercel web app continues to function perfectly, as no breaking API changes were introduced.
- **Responsive Layout**: Test on iPhone SE (small), iPhone 14 Pro Max (large), and iPad (if enabled) to ensure SwiftUI layouts flex properly.
- **Dark Mode**: The application is forced to dark mode per brand guidelines (`.preferredColorScheme(.dark)`), verify this holds true across device settings.

# Security Audit: Truckin all Day

## Overview
This document reviews the security posture of the Truckin all Day iOS application and its integration with the Vercel-hosted frontend and Fourthwall merch store.

## Current Architecture
- **Frontend / Backend**: The application is largely static and relies on HTML5, Javascript, and external embeds (Spotify, Fourthwall).
- **Authentication**: There is no direct user login on the main platform. The Fourthwall store handles its own secure checkout process.
- **Secrets**: No secrets or API keys are required for the static frontend.

## Security Review Findings
- **Data Storage**: The iOS App does not store sensitive user data locally.
- **Keychain Usage**: Not currently required. If user authentication is added, `Keychain` must be used for token storage.
- **Network Security**: All network requests (including WebViews for Spotify/Fourthwall) use secure `HTTPS`. App Transport Security (ATS) should remain enabled with no exceptions.
- **WebViews**: The Arcade games and Merch Store may run inside `WKWebView`. These views must have JavaScript enabled for games to run, but cross-site tracking and external navigation outside of trusted domains should be blocked using `WKNavigationDelegate`.

## Action Items Before Release
1. Implement restricted navigation in `WKWebView` to ensure users cannot browse the open internet from within the arcade or store.
2. Review Fourthwall's SDK/API if a native checkout flow is implemented in the future, ensuring PCI compliance is maintained on their end.
